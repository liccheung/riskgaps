numOfStates <- function(data){
  return(c(0:1))
}

##################### Condensing Data  #####################
DataSanitation <- function(initial_data){

  #Finds patterns in data
  #Outputs unique rows and a vector of frequency
  all_patterns <- as.data.frame(GetPatterns(initial_data))
  unique_patterns <- as.data.frame(table(all_patterns))

  pattern_list <- Pattern2Data(unique_patterns)
  state_pattern <- pattern_list[[1]]
  freq_vec <- pattern_list[[2]]

  return(list(state_pattern, freq_vec))
}

#Input: data matrix
#Output: all unique patterns, not in array/matrix form
GetPatterns <- function(states){

  scipen0 <- getOption("scipen")
  options(scipen = 999)
  vals <- rep(NaN,dim(states)[1])
  for (i in 1:dim(states)[1]){
    val <- ""
    for(j in 1:dim(states)[2]){
      if (!is.na(states[i,j])){
        states_val <- states[i,j]
      } else {
        states_val <- 2
      }
      val <- paste0(val, states_val)
    }

    vals[i] <- val
  }
  options(scipen=scipen0)  

  return(vals)
}

#Input: Output of GetPatterns
#Output: Matrix of all unique patterns, frequency vector
#ith entry of freq_vec is # of times ith row of state_mat occurs in the original matrix
Pattern2Data <- function(unique_patterns){

  time_length <- nchar(as.character(unique_patterns$all_patterns[[1]]))
  n <- dim(unique_patterns)[1]
  state_mat <- matrix(NaN,n,time_length)
  freq_vec <- numeric(n)
  for (i in 1:n){
    freq_vec[i] <- unique_patterns$Freq[[i]]
    pattern <- unique_patterns$all_patterns[[i]]

    for (time in 1:time_length){
      new_val <- as.integer(substr(pattern, time,time))
      if (new_val == 2){
        new_val <- NaN
      }
      state_mat[i,time] <- new_val
    }
  }
  return(list(state_mat, freq_vec))
}

