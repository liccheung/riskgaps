#' Likelihood accounting for registry gaps with 2 competing events
#' Assumes weibull baseline hazard for each cause
#' Assumes hazards for each cause depend on the same covariates
#'
#' @param resdata observed residence histories
#' values are 0 = outside of registry catchment area, or 1 = inside of registry catchment area
#'
#' @return observed mover stayer status (= 0 if always observed outside catchment, = 1 if always observed inside catchment,
#' and =2 if observed to have moved); and indicator if individual ever observed outside catchment
GetMovingStatus <- function(resdata){

  always_in  <- which(apply(resdata, 1, min, na.rm = TRUE) == 1)
  always_out <- which(apply(resdata, 1, max, na.rm = TRUE) == 0)
  movers <- setdiff(1:nrow(resdata), union(always_out,always_in))

  ms_status <- rep(NA,nrow(resdata))
  ms_status[always_out] <- 0
  ms_status[always_in]  <- 1
  ms_status[movers]     <- 2
  ever_out <- ifelse(ms_status != 1, 1, 0)

  data.frame(ever_out, ms_status)
}
