twoCompetingRisks <- function(data, time.var, event1.var, event2.var, residence.vars, 
                              residence.dates, cov.vars=NULL, op=NULL) {

  # Check the options list and data
  op   <- check_op(op, cov.vars, 2)
  data <- check_data(data, time.var, event1.var, residence.vars, cov.vars, 2, event2.var) 
  prt  <- op$print

  tmp             <- check_residence(residence.vars, residence.dates) 
  residence.vars  <- tmp$vars
  residence.dates <- tmp$dates

  tmp         <- getStartEndTimes(residence.dates)
  time_starts <- tmp$time_starts
  time_ends   <- tmp$time_ends

  if (prt) cat("Condensing data\n")
  tmp           <- DataSanitation(data[, residence.vars, drop=FALSE])
  state_pattern <- tmp[[1]]
  freq_vec      <- tmp[[2]]
  tmp           <- NULL
  gc()

  if (prt) cat("Calling EM algorithm\n")
  parameters <- myEM(state_pattern, freq_vec, op)

  # Obtain estimated posterior probabilities of residing inside catchment area at each year
  if (prt) cat("Compute posterior probabilities\n")
  decoded_prob <- myDecode(data[, residence.vars, drop=FALSE], state_pattern, 
                           parameters[[1]], parameters[[2]], parameters[[3]], parameters[[4]],
                           freq_vec, op)

  opt_start_values <- getInitEst2(op, data, time.var, event1.var, event2.var, cov.vars)
  rows1 <- data[[event1.var]] %in% 1
  rows2 <- data[[event2.var]] %in% 1
  tmp   <- !rows1 & !rows2
  rows0 <- (1:nrow(data))[tmp]
  rows1 <- (1:nrow(data))[rows1]
  rows2 <- (1:nrow(data))[rows2]

  if (prt) cat("Calling optim\n")
  tmp <- optim(par=opt_start_values, fn=loglik2, xsam=data, time.var=time.var, event1.var=event1.var, 
               event2.var=event2.var, covar=cov.vars, probability_out=1-decoded_prob,
               time_starts=time_starts, time_ends=time_ends, 
               rows0=rows0, rows1=rows1, rows2=rows2, 
               method="BFGS", control=list(trace=FALSE), hessian=TRUE)
  if (tmp$convergence) {
    print(tmp$message)
    warning(paste0("optim return value = ", tmp$convergence))
  }
  cox.estimates <- tmp$par
  cox.cov       <- solve(tmp$hessian)

  # proposed
  risk <- NULL
  if (op$abs.risk.compute) {
    if (prt) cat("Compute absolute risk \n")
    risk <- getAbsRisk2(cox.estimates, cox.cov, op, data, time.var, event1.var, event2.var, cov.vars)
  }

  ret <- list(abs.risk=risk, cox.estimates=cox.estimates, cox.cov=cox.cov, data=data,
              event.var=c(event1.var, event2.var), cov.vars=cov.vars )
  ret
}

getInitEst2 <- function(op, data, time.var, event1.var, event2.var, cov.vars) {

  ret <- op[["optim.init", exact=TRUE]]
  if (!is.null(ret)) return(ret)

  ret1 <- getInitEst(op, data, time.var, event1.var, cov.vars)
  names(ret1) <- paste0(names(ret1), ".1")
  ret2 <- getInitEst(op, data, time.var, event1.var, cov.vars)
  names(ret2) <- paste0(names(ret2), ".2")
  ret <- c(ret1, ret2)

  ret
}

#' Likelihood accounting for registry gaps with 2 competing events
#' Assumes weibull baseline hazard for each cause
#' Assumes hazards for each cause depend on the same covariates
#'
#' @param parest weibull model parameters for cause-1, followed by weibull model parameters for cause-2
#'               e.g(log(shape1), beta10, beta11,..., log(shape2), beta20, beta21,..)
#' @param xsam survival data with
#'              observed time stored as variable y,
#'              cause-1 event indicator stored as variable d1,
#'              cause-2 event indicator stored as variable d2
#' @param covar covariates to include in model
#' @param probability_out matrix of individual posterior probabilities of residing outside of catchment area.
#'        rows are individuals (in same order as Xmat), columns are years
#' @param time_starts vector of survival times at start of each yearly time period
#' @param time_ends vector of survival times at end of each yearly time period
#'
#' @return Log likelihood of observed data
loglik2.0 <- function(parest, xsam, time.var, event1.var, event2.var, covar, probability_out, time_starts, time_ends){
  y <- xsam[[time.var]]
  d1 <- xsam[[event1.var]]
  d2 <- xsam[[event2.var]]
  Xdat <- as.matrix(cbind(1, xsam[,covar]))

  num_covar <- length(covar)
  par1 <- parest[1:(2 + num_covar)]
  tmp <-  parest[-(1:(2 + num_covar))]
  par2 <- tmp[1:(2 + num_covar)]

  shape1 <- exp(par1[1])
  coeff1 <- par1[-1]
  lam1 <- exp(Xdat %*% coeff1)

  shape2 <- exp(par2[1])
  coeff2 <- par2[-1]
  lam2 <- exp(Xdat %*% coeff2)

  #weibull hazard function
  hweibull <- function(t, shape, scale){
    shape * (t/scale)^(shape - 1)/scale
    #equivalent to dweibull(t, shape, scale)/ (1 - pweibull(t, shape, scale))
  }

  #overall survival is product of cause-specific survivals
  Sfunc <- function(t,Xdat){
    (1 - pweibull(t, shape = shape1, scale = exp(Xdat %*% coeff1)))*
      (1 - pweibull(t, shape = shape2, scale = exp(Xdat %*% coeff2)))
  }

  #cause-specific densities are cause-specific hazards multiplied by overall survival
  f1func <- function(t, Xdat){
    hweibull(t, shape = shape1, scale = exp(Xdat %*% coeff1)) * Sfunc(t, Xdat)
  }
  f2func <- function(t, Xdat){
    hweibull(t, shape = shape2, scale = exp(Xdat %*% coeff2)) * Sfunc(t, Xdat)
  }

  #for each individual, calculate probability of missed event
  total_prob_missed <- vector(length = nrow(xsam))

  for(i in 1:nrow(xsam)){
    Xi <- Xdat[i,]
    yi <- y[i]
    pi_outs <- probability_out[i,]

    ui_starts <- ifelse(time_starts >= yi, 0, time_starts)
    vi_ends  <- ifelse(time_starts >= yi, 0,
                       ifelse(time_ends >= yi, yi, time_ends))

    yearly_prob_missed <- pi_outs * (Sfunc(ui_starts, Xi) - Sfunc(vi_ends, Xi))
    total_prob_missed[i]  <- sum(yearly_prob_missed)
  }

  ilik  <- f1func(y, Xdat)^d1 * f2func(y, Xdat)^d2 *
    (total_prob_missed + Sfunc(y, Xdat))^(1 - d1 - d2)

  -sum(I(log(ilik))) #log-likelihood
}


Sfunc2 <- function(t, shape1, shape2, scale1, scale2){

  ret <- (1 - pweibull(t, shape=shape1, scale=scale1))*(1 - pweibull(t, shape=shape2, scale=scale2))
  ret
}

hweibull <- function(t, shape, scale){
  #equivalent to dweibull(t, shape, scale)/ (1 - pweibull(t, shape, scale))
  shape * (t/scale)^(shape - 1)/scale  
}

f1func <- function(t, shape1, shape2, scale1, scale2){
  hweibull(t, shape=shape1, scale=scale1)*Sfunc2(t, shape1, shape2, scale1, scale2)
}
f2func <- function(t, shape1, shape2, scale1, scale2){
  hweibull(t, shape=shape2, scale=scale2)*Sfunc2(t, shape1, shape2, scale1, scale2)
}

loglik2 <- function(parest, xsam, time.var, event1.var, event2.var, covar, 
                    probability_out, time_starts, time_ends, rows0, rows1, rows2){

  y         <- xsam[[time.var]]
  d1        <- xsam[[event1.var]]
  d2        <- xsam[[event2.var]]
  num_covar <- length(covar)
  vec       <- 1:(2 + num_covar)
  par1      <- parest[vec]
  tmp       <- parest[-vec]
  par2      <- tmp[vec]
  shape1    <- exp(par1[1])
  coeff1    <- par1[-1]
  shape2    <- exp(par2[1])
  coeff2    <- par2[-1]
  nr        <- nrow(xsam)

  # Get lam1, lam2
  if (num_covar) {
    tmp  <- as.matrix(xsam[, covar, drop=FALSE])
    lam1 <- as.vector(exp(coeff1[1] + tmp %*% coeff1[-1]))
    lam2 <- as.vector(exp(coeff2[1] + tmp %*% coeff2[-1]))
  } else {
    lam1 <- rep(exp(coeff1[1]), nr)
    lam2 <- rep(exp(coeff2[1]), nr)
  }

  #for each individual, calculate probability of missed event
  total_prob_missed <- rep(1, nr)
  ilik0             <- total_prob_missed
  ilik1             <- ilik0
  ilik2             <- ilik0

  if (length(rows0)) {
    for(i in rows0){
      yi                   <- y[i]
      ui_starts            <- time_starts
      vi_ends              <- time_ends
      tmp                  <- time_starts >= yi
      ui_starts[tmp]       <- 0
      vi_ends[tmp]         <- 0
      tmp                  <- !tmp & (time_ends >= yi)
      vi_ends[tmp]         <- yi  
      lam1i                <- lam1[i]
      lam2i                <- lam2[i]
      tmp1                 <- Sfunc2(ui_starts, shape1, shape2, lam1i, lam2i)
      if (any(!is.finite(tmp1))) return(NaN)
      tmp2                 <- Sfunc2(vi_ends, shape1, shape2, lam1i, lam2i)
      if (any(!is.finite(tmp2))) return(NaN)
      yearly_prob_missed   <- probability_out[i,]*(tmp1 - tmp2)
      total_prob_missed[i] <- sum(yearly_prob_missed)
    }
    ilik0[rows0] <- total_prob_missed[rows0] + Sfunc2(y[rows0], shape1, shape2, lam1[rows0], lam2[rows0])
  }

  #ilik  <- f1func(y, shape1, shape2, lam1, lam2)^d1 * f2func(y, shape1, shape2, lam1, lam2)^d2 *
  #  (total_prob_missed + Sfunc2(y, shape1, shape2, lam1, lam2))^(1 - d1 - d2)
  ilik1[rows1] <- f1func(y[rows1], shape1, shape2, lam1[rows1], lam2[rows1])
  ilik2[rows2] <- f2func(y[rows2], shape1, shape2, lam1[rows2], lam2[rows2])
  ilik         <- ilik1*ilik2*ilik0

  -sum(log(ilik)) #log-likelihood
}

#' Calculate absolute risk of event 1 based on likelihood model with 2 competing events
#'
#' @param lik likelihood model with 2 competing events
#' @param num_covar number of covariates used in model, used to separate model parameters associated with each cause
#' @param newdata covariate data for absolute risk prediction
#' @param tout time points for prediction
#'
#' @return estimated absolute risk and standard errors for event 1
#' where rows are individuals and columns correspond to time points


##Functions for estimating absolute risks from proposed likelihood
gcuminc2.0 <- function(lik, num_covar, newdata, tout){

    #absolute risk for newdata at a single time point
    gcuminc.t0 <- function(lik, num_covar, newdata, tout){

      #absolute risk for a given set of design covariates xi
      cuminc.individual <- function(xi){

        integrand <- function(t, xi, likpar){
          par1 <- likpar[1:(2 + num_covar)]
          par2 <- likpar[-(1:(2 + num_covar))]

          shape1 <- exp(par1[1])
          coeff1 <- par1[-1]
          shape2 <- exp(par2[1])
          coeff2 <- par2[-1]

          #expression for cause-1 density
          dweibull(t, shape = shape1, scale = exp(xi %*% coeff1))*
            (1 - pweibull(t, shape = shape2, scale = exp(xi %*% coeff2)))
        }

        gfunc <- function(x){integrate(integrand,lower = 0, upper = tout, xi, x)$value}

        #calculate absolute risk standard error using delta method
        DD <- as.matrix(numDeriv::grad(gfunc, lik$par))
        VAR <- solve(lik$hessian)
        Vg <- t(DD) %*% VAR %*% DD

        risk <- gfunc(lik$par)
        se <- as.numeric(sqrt(Vg))

        return(c(risk, se))
      }

      matdata <- as.matrix(cbind(1, newdata))
      res <- apply(matdata, 1, cuminc.individual )
      return(list(absRisk = res[1,], absRisk.se = res[2,], times = tout, newdata = newdata))
    }

    #absolute risks for newdata over time vector
    estMat <- matrix(nrow = nrow(newdata), ncol = length(tout))
    seMat <- matrix(nrow = nrow(newdata), ncol = length(tout))

    for(i in seq_along(tout)){
      tmp <- gcuminc.t0(lik, num_covar, newdata, tout[i])
      estMat[,i] <- tmp[["absRisk"]]
      seMat[,i] <- tmp[["absRisk.se"]]
    }
    return(list(absRisk = estMat, absRisk.se = seMat, times = tout))
}

integrand2 <- function(t, xi, likpar, vec){

  par1   <- likpar[vec]
  par2   <- likpar[-vec]
  shape1 <- exp(par1[1])
  coeff1 <- par1[-1]
  shape2 <- exp(par2[1])
  coeff2 <- par2[-1]

  #expression for cause-1 density
  dweibull(t, shape=shape1, scale=exp(sum(xi*coeff1)))*
          (1 - pweibull(t, shape=shape2, scale= exp(sum(xi*coeff2))))
}

gfunc2 <- function(x, tout, xi, vec){

  integrate(integrand2, lower=0, upper=tout, xi, x, vec)$value

}

cuminc.individual2 <- function(xi, lik.par, tout, vec, VAR){

  #calculate absolute risk standard error using delta method
  DD   <- as.matrix(numDeriv::grad(gfunc2, method="Richardson", side=NULL, method.args=list(),
                                   lik.par, tout, xi, vec))
  Vg   <- t(DD) %*% VAR %*% DD
  risk <- gfunc2(lik.par, tout, xi, vec)
  se   <- as.numeric(sqrt(Vg))

  return(c(risk, se))
}

#absolute risk for newdata at a single time point
gcuminc2.t0 <- function(lik.par, vec, matdata, tout, VAR){

  nr   <- nrow(matdata)
  risk <- rep(NA, nr)
  se   <- risk
  for (i in 1:nr) {
    tmp     <- cuminc.individual2(matdata[i, ], lik.par, tout, vec, VAR)

    #tmp     <- try(cuminc.individual2(matdata[i, ], lik.par, tout, vec, VAR), silent=TRUE)
    if (!("try-error" %in% class(tmp))) {
      risk[i] <- tmp[1]
      se[i]   <- tmp[2]
    }
  }
  list(absRisk=risk, absRisk.se=se, times = tout)
}

gcuminc2 <- function(parms, var_cov, newdata, times){

 if (!length(newdata)) {
    matdata   <- as.matrix(1)
    nr        <- 1
    num_covar <- 0
  } else {
    matdata   <- as.matrix(cbind(1, newdata))
    nr        <- nrow(newdata)
    num_covar <- ncol(newdata)
  }
  if (length(parms) != 2*(2+num_covar)) stop("ERROR with parms and/or newdata")
  vec <- 1:(2 + num_covar)
   
  #absolute risks for newdata over time vector
  estMat <- matrix(nrow = nr, ncol = length(times))
  seMat <- matrix(nrow = nr, ncol = length(times))

  for(i in seq_along(times)){
    tmp        <- gcuminc2.t0(parms, vec, matdata, times[i], var_cov)
    estMat[,i] <- tmp[["absRisk"]]
    seMat[,i]  <- tmp[["absRisk.se"]]
  }
  return(list(absRisk = estMat, absRisk.se = seMat, times = times))
}

getAbsRisk2 <- function(cox.estimates, cox.cov, op, data, time.var, event1.var, event2.var, cov.vars) {

  event.vars <- c(event1.var, event2.var)
  rtimes     <- getAbsRiskTimes(op, data, time.var, event.vars) 
  ncovar     <- length(cov.vars)
  nr         <- nrow(data)
  if (ncovar) {
    xids  <- myPasteCols(data[, cov.vars, drop=FALSE], sep=":")
    uids  <- unique(xids)
    rows  <- match(xids, uids)
    tmp   <- !duplicated(xids)
    data2 <- data[tmp, cov.vars, drop=FALSE]   
  } else {
    data2 <- NULL
  }
  obj              <- gcuminc2(cox.estimates, cox.cov, data2, rtimes)
  if (ncovar) {
    obj$absRisk    <- obj$absRisk[rows, , drop=FALSE] 
    obj$absRisk.se <- obj$absRisk.se[rows, , drop=FALSE]
  } else {
    obj$absRisk    <- matrix(rep(obj$absRisk, times=nr),    nrow=nr, ncol=length(rtimes), byrow=TRUE)
    obj$absRisk.se <- matrix(rep(obj$absRisk.se, times=nr), nrow=nr, ncol=length(rtimes), byrow=TRUE)
  }
  
  obj
}




#For simulation, calculate true absolute risk based on proportional hazard model
# parameters
#same as gcuminc2 but does not return standard errors
truecuminc2 <- function(a1,b1,B1, a2,b2,B2, newdata,tout){

  truecuminc.t0 <- function(a1,b1,B1, a2,b2,B2, newdata,ti){
    #xi <- as.matrix(cbind(1,newdata[1,]))
    cuminc.individual <- function(xi){
      integrand <- function(t,xi){
        shape1 <- a1
        coeff1 <- c(log(b1), -B1/a1)
        shape2 <- a2
        coeff2 <- c(log(b2), -B2/a2)

        dweibull(t, shape = shape1, scale = exp(xi %*% coeff1))*
          (1 - pweibull(t, shape = shape2, scale = exp(xi %*% coeff2)))
      }

      risk <- integrate(integrand,lower = 0, upper = ti, xi)$value
    }
    matdata <- as.matrix(cbind(1,newdata))
    res <- apply(matdata,1, cuminc.individual )
    list(absRisk = res)
  }

  estMat <- matrix(nrow = nrow(newdata), ncol = length(tout))
  for(i in seq_along(tout)){
    tmp <- truecuminc.t0(a1,b1,B1, a2,b2,B2, newdata, tout[i])
    estMat[,i] <- tmp[["absRisk"]]
  }
  return(list(absRisk = estMat, times = tout, newdata = newdata))
}
