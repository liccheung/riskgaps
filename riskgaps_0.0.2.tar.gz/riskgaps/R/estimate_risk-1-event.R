noCompetingRisks <- function(data, time.var, event.var, residence.vars, residence.dates, cov.vars=NULL, op=NULL) {

  # Check the options list and data
  op   <- check_op(op, cov.vars, 1)
  data <- check_data(data, time.var, event.var, residence.vars, cov.vars, 1, NULL) 
  prt  <- op$print

  tmp             <- check_residence(residence.vars, residence.dates) 
  residence.vars  <- tmp$vars
  residence.dates <- tmp$dates

  tmp         <- getStartEndTimes(residence.dates)
  time_starts <- tmp$time_starts
  time_ends   <- tmp$time_ends

  if (prt) cat("Condensing data\n")
  tmp           <- DataSanitation(data[, residence.vars, drop=FALSE])
  state_pattern <- tmp[[1]]
  freq_vec      <- tmp[[2]]
  tmp           <- NULL
  gc()

  if (prt) cat("Calling EM algorithm\n")
  parameters <- myEM(state_pattern, freq_vec, op)

  # Obtain estimated posterior probabilities of residing inside catchment area at each year
  if (prt) cat("Compute posterior probabilities\n")
  decoded_prob <- myDecode(data[, residence.vars, drop=FALSE], state_pattern, 
                           parameters[[1]], parameters[[2]], parameters[[3]], parameters[[4]],
                           freq_vec, op)

  opt_start_values <- getInitEst(op, data, time.var, event.var, cov.vars)
  tmp   <- data[[event.var]] == 1
  rows1 <- (1:nrow(data))[tmp]
  rows0 <- (1:nrow(data))[!tmp]

  if (prt) cat("Calling optim\n")
  tmp <- optim(par=opt_start_values, fn=loglik1, xsam=data, time.var=time.var, event.var=event.var, 
               covar=cov.vars, probability_out=1-decoded_prob,
               time_starts=time_starts, time_ends=time_ends, rows1=rows1, rows0=rows0, 
               method="BFGS", control=list(trace=FALSE), hessian=TRUE)
  if (tmp$convergence) {
    print(tmp$message)
    warning(paste0("optim return value = ", tmp$convergence))
  }
  cox.estimates <- tmp$par
  cox.cov       <- solve(tmp$hessian)

  # proposed
  risk <- NULL
  if (op$abs.risk.compute) {
    if (prt) cat("Compute absolute risk \n")
    risk <- getAbsRisk1(cox.estimates, cox.cov, op, data, time.var, event.var, cov.vars)
  }

  ret <- list(abs.risk=risk, cox.estimates=cox.estimates, cox.cov=cox.cov, data=data,
              event.var=event.var, cov.vars=cov.vars)
  ret
}

getInitEst <- function(op, data, time.var, event.var, cov.vars) {

  ret <- op[["optim.init", exact=TRUE]]
  if (!is.null(ret)) return(ret)

  str <- paste0("Surv(", time.var, ",", event.var, ") ~ ")
  if (length(cov.vars)) {
    str <- paste0(str, paste(cov.vars, collapse=" + ", sep=""))
  } else {
    str <- paste0(str, "1")
  }
  form  <- as.formula(str) 
  fit   <- survreg(form, data=data, dist="weibull")
  shape <- log(1/fit$scale)
  coef  <- fit$coefficients
  nms   <- names(coef)
  ret   <- c(shape, coef)
  names(ret) <- c("log(shape)", nms) 

  ret
}


#' Likelihood accounting for registry gaps with no competing risks
#' Assumes weibull baseline hazard
#'
#' @param parest weibull model parameters (log shape, beta0, beta1,...)
#' @param xsam survival data with observed time stored as variable y, and event indicator stored as variable d
#' @param covar covariates to include in model
#' @param probability_out matrix of individual posterior probabilities of residing outside of catchment area.
#'        rows are individuals (in same order as Xmat). columns are years
#' @param time_starts vector of survival times at start of each yearly time period
#' @param time_ends vector of survival times at end of each yearly time period
#'
#' @return Log likelihood of observed data
#'
loglik1.0 <- function(parest, xsam, time.var, event.var, covar, probability_out, time_starts, time_ends){
  y <- xsam[[time.var]]
  d1 <- xsam[[event.var]]
  Xdat <- as.matrix(cbind(1,xsam[,covar]))
  num_covar <- length(covar)

  par1 <- parest[1:(2 + num_covar)]
  shape1 <- exp(par1[1])
  coeff1 <- par1[-1]
  lam1 <- exp(Xdat %*% coeff1)

  Sfunc <- function(t, Xdat){
    (1 - pweibull(t, shape = shape1, scale = exp(Xdat %*% coeff1)))
  }

  #for each individual, calculate probability of missed event
  total_prob_missed <- vector(length = nrow(xsam))

  for(i in 1:nrow(xsam)){
    Xi <- Xdat[i,]
    yi <- y[i]
    pi_outs <- probability_out[i,]

    ui_starts <- ifelse(time_starts >= yi, 0, time_starts)
    vi_ends  <- ifelse(time_starts >= yi, 0,
                       ifelse(time_ends >= yi, yi, time_ends))

    yearly_prob_missed <- pi_outs * (Sfunc(ui_starts, Xi) - Sfunc(vi_ends, Xi))
    total_prob_missed[i]  <- sum(yearly_prob_missed)
  }

  ilik  <- dweibull(y, shape = shape1, scale = lam1)^d1*
    (total_prob_missed + (1 - pweibull(y, shape = shape1, scale = lam1)))^(1-d1)

  -sum(I(log(ilik))) #log-likelihood
}

SfuncDiff1 <- function(starts, ends, shape1, scale) {
  ret <- pweibull(ends, shape=shape1, scale=scale) - pweibull(starts, shape=shape1, scale=scale) 
}

loglik1 <- function(parest, xsam, time.var, event.var, covar, probability_out, 
                    time_starts, time_ends, rows1, rows0){
  y    <- xsam[[time.var]]
  d1   <- xsam[[event.var]]
  nr   <- nrow(xsam)

  num_covar <- length(covar)
  par1      <- parest[1:(2 + num_covar)]
  shape1    <- exp(par1[1])
  coeff1    <- par1[-1]

  # Get lam1
  if (num_covar) {
    lam1 <- as.vector(exp(coeff1[1] + (as.matrix(xsam[, covar, drop=FALSE]) %*% coeff1[-1])))
  } else {
    lam1 <- rep(exp(coeff1[1]), nr)
  }

  #for each individual, calculate probability of missed event
  total_prob_missed <- rep(1, nr)
  ilik1             <- total_prob_missed
  ilik0             <- ilik1

  if (length(rows0)) {
    for(i in rows0){
      yi             <- y[i]
      ui_starts      <- time_starts
      vi_ends        <- time_ends
      tmp            <- time_starts >= yi
      ui_starts[tmp] <- 0
      vi_ends[tmp]   <- 0
      tmp            <- !tmp & (time_ends >= yi)
      vi_ends[tmp]   <- yi  

      yearly_prob_missed    <- probability_out[i,]*SfuncDiff1(ui_starts, vi_ends, shape1, lam1[i]) 
      tmp                   <- sum(yearly_prob_missed)
      if (!is.finite(tmp)) return(tmp)
      total_prob_missed[i]  <- tmp
    }
    ilik0[rows0] <- total_prob_missed[rows0] + (1 - pweibull(y[rows0], shape=shape1, scale=lam1[rows0]))
  }

  #ilik  <- dweibull(y, shape = shape1, scale = lam1)^d1*
  #  (total_prob_missed + (1 - pweibull(y, shape = shape1, scale = lam1)))^(1-d1)
  ilik1[rows1] <- dweibull(y[rows1], shape=shape1, scale=lam1[rows1])
  ilik         <- ilik1*ilik0

  -sum(log(ilik)) #log-likelihood
}



#' Calculate absolute risk of event 1 based on likelihood model with no competing events
#'
#' @param lik likelihood model with no competing events
#' @param num_covar number of covariates used in model
#' @param newdata covariate data for absolute risk prediction
#' @param tout time points for prediction
#'
#' @return estimated absolute risk and standard errors
#' where rows are individuals and columns correspond to time points
#'
gcuminc1.0 <- function(lik, num_covar, newdata, tout){

  #absolute risk for newdata at a single time point
  gcuminc.t0 <- function(lik, num_covar, newdata, tout){

    #absolute risk for a given set of design covariates xi
    cuminc.individual <- function(xi){

      integrand <- function(t, xi, likpar){

        par1 <- likpar[1:(2 + num_covar)]
        shape1 <- exp(par1[1])
        coeff1 <- par1[-1]
        #expression for cause 1 specific density function
        dweibull(t, shape = shape1, scale = exp(xi %*% coeff1))
      }

      gfunc <- function(x){integrate(integrand,lower = 0, upper = tout, xi, x)$value}

      #calculate absolute risk standard error using delta method
      DD <- as.matrix(numDeriv::grad(gfunc, lik$par))
      VAR <- solve(lik$hessian)
      Vg <- t(DD) %*% VAR %*% DD

      risk <- gfunc(lik$par)
      se <- as.numeric(sqrt(Vg))

      return(c(risk, se))
    }

    matdata <- as.matrix(cbind(1, newdata))
    res <- apply(matdata, 1, cuminc.individual )

    return(list(absRisk = res[1,], absRisk.se = res[2,], times = tout, newdata = newdata))
  }

  #absolute risks for newdata over time vector
  estMat <- matrix(nrow = nrow(newdata), ncol = length(tout))
  seMat <- matrix(nrow = nrow(newdata), ncol = length(tout))

  for(i in seq_along(tout)){
    tmp <- gcuminc.t0(lik, num_covar, newdata, tout[i])
    estMat[,i] <- tmp[["absRisk"]]
    seMat[,i] <- tmp[["absRisk.se"]]
  }
  return(list(absRisk = estMat, absRisk.se = seMat, times = tout, newdata = newdata))
}

gfunc_new <- function(x, tout, xi, num_covar) {

  par1   <- x[1:(2 + num_covar)]
  shape1 <- exp(par1[1])
  coeff1 <- par1[-1]
  p1     <- pweibull(tout, shape=shape1, scale=exp(sum(xi*coeff1)))
  p1

}

cuminc.individual_new <- function(xi, lik.par, tout, num_covar, VAR){

  #calculate absolute risk standard error using delta method
  DD   <- as.matrix(numDeriv::grad(gfunc_new, method="Richardson", side=NULL, method.args=list(),
                                   lik.par, tout, xi, num_covar))
  Vg   <- t(DD) %*% VAR %*% DD
  risk <- gfunc_new(lik.par, tout, xi, num_covar)
  se   <- as.numeric(sqrt(Vg))

  return(c(risk, se))
}

gcuminc.t0_new <- function(lik.par, num_covar, matdata, tout, VAR){

  #res <- apply(matdata, 1, cuminc.individual_new, lik, tout, num_covar, VAR)
  #return(list(absRisk = res[1,], absRisk.se = res[2,], times = tout))

  nr   <- nrow(matdata)
  risk <- rep(NA, nr)
  se   <- risk
  for (i in 1:nr) {
    tmp     <- try(cuminc.individual_new(matdata[i, ], lik.par, tout, num_covar, VAR), silent=TRUE)
    risk[i] <- tmp[1]
    se[i]   <- tmp[2]
  }
  list(absRisk=risk, absRisk.se=se, times = tout)
}

gcuminc1 <- function(parms, var_cov, newdata, times){

  if (!length(newdata)) {
    matdata   <- as.matrix(1)
    nr        <- 1
    num_covar <- 0
  } else {
    matdata   <- as.matrix(cbind(1, newdata))
    nr        <- nrow(newdata)
    num_covar <- ncol(newdata)
  }
  if (length(parms) != 2+num_covar) stop("ERROR with parms and/or newdata")

  #absolute risks for newdata over time vector
  estMat    <- matrix(nrow = nr, ncol = length(times))
  seMat     <- matrix(nrow = nr, ncol = length(times))
  
  for(i in seq_along(times)){
    tmp        <- gcuminc.t0_new(parms, num_covar, matdata, times[i], var_cov)
    estMat[,i] <- tmp[["absRisk"]]
    seMat[,i]  <- tmp[["absRisk.se"]]
  }
  return(list(absRisk = estMat, absRisk.se = seMat, times = times))
}

getAbsRisk1 <- function(cox.estimates, cox.cov, op, data, time.var, event.var, cov.vars) {

  rtimes  <- getAbsRiskTimes(op, data, time.var, event.var) 
  ncovar  <- length(cov.vars)
  nr      <- nrow(data)
  if (ncovar) {
    xids  <- myPasteCols(data[, cov.vars, drop=FALSE], sep=":")
    uids  <- unique(xids)
    rows  <- match(xids, uids)
    tmp   <- !duplicated(xids)
    data2 <- data[tmp, cov.vars, drop=FALSE]   
  } else {
    data2 <- NULL
  }
  obj            <- gcuminc1(cox.estimates, cox.cov, data2, rtimes)
  if (ncovar) {
    obj$absRisk    <- obj$absRisk[rows, , drop=FALSE] 
    obj$absRisk.se <- obj$absRisk.se[rows, , drop=FALSE]
  } else {
    obj$absRisk    <- matrix(rep(obj$absRisk, times=nr),    nrow=nr, ncol=length(rtimes), byrow=TRUE)
    obj$absRisk.se <- matrix(rep(obj$absRisk.se, times=nr), nrow=nr, ncol=length(rtimes), byrow=TRUE)
  }
  
  obj
}

#For simulation, calculate true absolute risk based on proportional hazard model
# parameters
#same as gcuminc1 but does not return standard errors
truecuminc1 <- function(a1, b1, B1, newdata,tout){

  truecuminc.t0 <- function(a1,b1,B1, newdata,ti){
    #xi <- as.matrix(cbind(1,newdata[1,]))
    cuminc.individual <- function(xi){
      integrand <- function(t,xi){
        shape1 <- a1
        coeff1 <- c(log(b1), -B1/a1)

        dweibull(t, shape = shape1, scale = exp(xi %*% coeff1))
      }

      risk <- integrate(integrand,lower = 0, upper = ti, xi)$value
    }
    matdata <- as.matrix(cbind(1,newdata))
    res <- apply(matdata,1, cuminc.individual )
    list(absRisk = res)
  }

  estMat <- matrix(nrow = nrow(newdata), ncol = length(tout))
  for(i in seq_along(tout)){
    tmp <- truecuminc.t0(a1,b1,B1, newdata, tout[i])
    estMat[,i] <- tmp[["absRisk"]]
  }
  return(list(absRisk = estMat, times = tout, newdata = newdata))
}

