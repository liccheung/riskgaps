
check_data <- function(data, time.var, event.var, year.vars, cov.vars, which, event2.var) {

  if (!length(data)) stop("ERROR: data must be a data frame")
  if (!is.data.frame(data)) stop("ERROR: data must be a data frame")
  if (!nrow(data)) stop("ERROR: data contains no rows")
  if (!ncol(data)) stop("ERROR: data contains no columns")
  
  check_time_var(data, time.var)
  if (which == 1) {
    check_event_var(data, event.var)
  } else {
    check_event_var(data, event.var,  nm="event1.var")
    check_event_var(data, event2.var, nm="event2.var")
  }
  check_year_vars(data, year.vars) 
  check_cov_vars(data, cov.vars)
  vars <- c(time.var, event.var, event2.var, cov.vars)
  keep <- rep(TRUE, nrow(data))
  for (var in vars) keep <- keep & is.finite(unlist(data[, var, drop=TRUE]))
  data <- data[keep, , drop=FALSE]
  if (!nrow(data)) stop("ERROR: all rows in data have been removed")
  vars  <- c(time.var, event.var, event2.var, cov.vars, year.vars)
  data  <- data[, vars, drop=FALSE]
  evec1 <- unlist(data[, event.var])
  n1    <- sum(evec1) 
  if (!n1) {
    if (which == 1) {
      stop("ERROR: data contains no events")
    } else {
      stop("ERROR: data contains no events for event 1")
    }
  }
  if (which == 2) {
    evec2 <- unlist(data[, event2.var])
    n2    <- sum(evec2) 
    if (!n2) stop("ERROR: data contains no events for event 2")
    tmp   <- (evec1 %in% 1) & (evec2 %in% 1)
    if (any(tmp)) stop("ERROR: data contains subjects with both events")
  }

  data

}

check_numeric_var <- function(data, var, varname) {

  n <- length(var)
  if (!n) stop(paste0("ERROR: ", varname, " must be specified"))
  if (n > 1) stop(paste0("ERROR: ", varname, " must be a single variable name"))
  if (!isString(var)) stop(paste0("ERROR: ", varname, " must be a variable name"))
  if (!(var %in% colnames(data))) stop(paste0("ERROR: the variable ", var, " is not in the data"))
  vec <- unlist(data[, var, drop=TRUE])
  if (!is.numeric(vec)) stop(paste0("ERROR: the variable ", var, " must be numeric")) 
  vec

}

check_time_var <- function(data, var) {

  vec <- check_numeric_var(data, var, "time.var") 
  tmp <- vec <= 0
  tmp[is.na(tmp)] <- FALSE
  if (any(tmp)) stop("ERROR: time.var must contain positive values")
  if (any(is.infinite(vec))) stop("ERROR: time.var must contain finite values")
  NULL
}

check_event_var <- function(data, var, nm="event.var") {

  vec <- check_numeric_var(data, var, nm) 
  tmp <- !(vec %in% c(0, 1, NA, NaN))
  tmp[is.na(tmp)] <- TRUE
  if (any(tmp)) stop(paste0("ERROR: ", nm, " can only contain values 0, 1, NA"))
  NULL
}

check_year_vars <- function(data, vars) {

  if (!length(vars)) stop("ERROR: residence.vars must be specified")
  for (var in vars) {
    vec <- check_numeric_var(data, var, "residence.vars") 
    tmp <- !(vec %in% c(0, 1, NA, NaN))
    tmp[is.na(tmp)] <- TRUE
    if (any(tmp)) stop(paste0("ERROR: the residence.vars ", var, " can only contain values 0, 1, NA"))
  }
  NULL
}

check_cov_vars <- function(data, vars) {

  if (!length(vars)) return(NULL)

  for (var in vars) {
    vec <- check_numeric_var(data, var, "cov.vars") 
  }
  NULL
}

isString <- function(obj) {

  if ((length(obj) == 1) && is.character(obj)) {
    ret <- TRUE
  } else {
    ret <- FALSE
  }
  ret
}

check_residence <- function(vars, dates) {

  nvars  <- length(vars)
  ndates <- length(dates)
  if (nvars != ndates) stop("ERROR: length(residence.vars) != length(residence.dates)")
  if (!is.character(dates) && !is.numeric(dates)) {
    stop("ERROR: residence.dates must be a numeric vector or a character vector of the form yyyy-mm-dd")
  }
  if (is.character(dates)) {
    len <- nchar(dates)
    tmp <- len != 10
    if (any(tmp)) stop("ERROR: residence.dates must be of the form yyyy-mm-dd")
    LEN <- ndates*3
    tmp <- as.numeric(unlist(strsplit(dates, "-", fixed=TRUE)))
    if (length(tmp) != LEN) stop("ERROR: residence.dates must be of the form yyyy-mm-dd")
    mat <- matrix(data=tmp, nrow=ndates, ncol=3)
    if (any(!is.finite(mat))) stop("ERROR: residence.dates must be of the form yyyy-mm-dd")
    tmp <- (mat[, 1] < 1950)
    if (any(tmp)) stop("ERROR: the years component in residence.dates must be >= 1950")
    tmp <- (mat[, 2] < 1) | (mat[, 2] > 12)
    if (any(tmp)) stop("ERROR: the months component in residence.dates must be between 1 and 12")
    tmp <- (mat[, 3] < 1) | (mat[, 3] > 31)
    if (any(tmp)) stop("ERROR: the days component in residence.dates must be between 1 and 31")
  } else {
    if (any(!is.finite(dates))) stop("ERROR: residence.dates must be finite positive values")
    if (any(dates < 0)) stop("ERROR: residence.dates must be finite positive values")
  }
  tmp   <- sort(dates, index.return=TRUE)
  ids   <- tmp$ix
  dates <- dates[ids]
  vars  <- vars[ids]
  
  list(vars=vars, dates=dates)
}

getStartEndTimes <- function(dates) {

  n            <- length(dates)
  if (is.character(dates)) {
    dates        <- ymd(dates)
    time_starts  <- as.duration(dates[1] %--% dates[1:(n-1)])/dyears(1)
    time_ends    <- as.duration(dates[1] %--% dates[2:n])/dyears(1)
  } else {
    time_starts  <- dates[1:(n-1)]
    time_ends    <- dates[2:n]
  } 
  time_starts <- c(0, time_starts)
  time_ends   <- c(0, time_ends)

  list(time_starts=time_starts, time_ends=time_ends)
}

getAbsRiskTimes <- function(op, data, time.var, event.vars) {

  ret <- op[["abs.risk.times", exact=TRUE]]
  if (is.null(ret)) {
    tmp <- rep(FALSE, nrow(data))
    for (v in event.vars) tmp <- tmp | (unlist(data[, v]) %in% 1)
    vec <- unlist(data[tmp, time.var])
    ret <- quantile(vec, probs=c(0.25, 0.5, 0.75, 1))
  }
  ret <- sort(unique(ret))
  ret
}

check_op <- function(op, covs, which) {

  valid   <- c("ms.r_0", "ms.p_00", "ms.p_11", "ms.pi_0", "ms.pi_1",
               "em.eps", "em.maxiter", "print", 
               "abs.risk.compute", "abs.risk.times", "optim.init")
  default <- list(0.3, 0.1, 0.4, 0.9, 0.9,
                  1e-6, 100000, 1, 
                  TRUE, NULL, NULL) 

  if (length(op)) {
    if (!is.list(op)) stop("ERROR: op must be a list")
  }
  op  <- default.list(op, valid, default)
  nms <- names(op)
  tmp <- !(nms %in% valid)
  if (any(tmp)) {
    err <- nms[tmp]
    str <- paste(err, collapse=", ", sep="")
    msg <- paste0("ERROR: the name(s) ", str, " are not valid options")
    stop(msg) 
  }
  
  vec <- op[["optim.init", exact=TRUE]]
  len <- length(vec)
  if (len) { 
    clen <- length(covs) + 2*which
    if (len != clen) stop(paste0("ERROR: optim.init should have length ", clen))
    if (!is.numeric(vec)) stop("ERROR: optim.init should be a numeric vector")  
    if (!is.vector(vec)) stop("ERROR: optim.init should be a numeric vector")  
  }

  vec <- op[["abs.risk.times", exact=TRUE]]
  if (length(vec)) {
    if (!is.numeric(vec) || !is.vector(vec)) stop("ERROR: abs.risk.times should be a numeric vector")  
    tmp <- vec < 0
    tmp[is.na(tmp)] <- TRUE
    if (any(tmp)) stop("ERROR: abs.risk.times should contain positive values") 
  }

  op

}




#define IARG_DEBUG 0
#define IARG_data_nr 1
#define IARG_data_nc 2
#define IARG_freqVecLen 3
#define IARG_maxiter 4
#define IARG_print 5
#define IARG_kLen 6

#define DARG_r_0 0
#define DARG_p_00 1
#define DARG_p_11 2
#define DARG_pi_0 3
#define DARG_pi_1 4
#define DARG_epsilon 5
#define DARG_machine_eps 6

get_args <- function(data, freq_vec, op) {
 
  reti <- c(0, nrow(data), ncol(data), length(freq_vec), op$em.maxiter, op$print, 2)
  if (length(reti) != 7) stop("ERROR1")

  retd <- c(op$ms.r_0, op$ms.p_00, op$ms.p_11, op$ms.pi_0, op$ms.pi_1, op$em.eps, .Machine$double.eps)
  if (length(retd) != 7) stop("ERROR2")

  list(iargs=reti, dargs=retd)

}

myEM <- function(data, freq_vec, op) {

  tmp       <- get_args(data, freq_vec, op)
  iargs     <- tmp$iargs
  dargs     <- tmp$dargs
  kvec      <- numOfStates(data)
  klen      <- length(kvec)
  ret_code  <- as.integer(-1)
  ret_init  <- as.numeric(rep(-1, klen))
  ret_trans <- as.numeric(rep(-1, klen*klen))
  ret_pi0   <- as.numeric(-1)
  ret_pi1   <- as.numeric(-1)
  MISSING   <- 9
  datavec   <- as.vector(t(data))
  tmp       <- !is.finite(datavec)
  if (any(tmp)) datavec[tmp] <- MISSING

  tmp <- .C("MY_C_EM", as.integer(iargs), as.numeric(dargs), 
                    as.integer(datavec), as.integer(freq_vec), as.integer(kvec),
                    ret_code=ret_code, ret_init=ret_init, ret_trans=ret_trans,
                    ret_pi0=ret_pi0, ret_pi1=ret_pi1)
  
  ret_code  = tmp$ret_code
  if (ret_code != 1) stop("EM algorithm did not converge")
  ret_init  = tmp$ret_init
  ret_trans = matrix(data=tmp$ret_trans, nrow=klen, ncol=klen, byrow=TRUE)
  ret_pi0   = tmp$ret_pi0
  ret_pi1   = tmp$ret_pi1

  list(ret_init, ret_trans, ret_pi0, ret_pi1)
}

default.list <- function(inList, names, default, error=NULL,
                         checkList=NULL) {

  # inList      List
  # names       Vector of names of items in inList
  # default     List of default values to assign if a name is not found
  #             The order of default must be the same as in names.
  # error       Vector of TRUE/FALSE if it is an error not to have the
  #             name in the list. 
  #             The default is NULL
  # checkList   List of valid values for each name.
  #             Use NA to skip a list element.
  #             The default is NULL

  n1 <- length(names)
  n2 <- length(default)
  if (n1 != n2) stop("ERROR: in calling default.list")

  if (is.null(error)) {
    error <- rep(0, times=n1)
  } else if (n1 != length(error)) {
    stop("ERROR: in calling default.list")
  }

  if (!is.null(checkList)) {
    if (n1 != length(checkList)) stop("ERROR: in calling default.list")
    checkFlag <- 1
  } else {
    checkFlag <- 0
  } 

  if (is.null(inList)) inList <- list()

  listNames <- names(inList)
  for (i in 1:n1) {
    if (!(names[i] %in% listNames)) {
      if (!error[i]) {
        inList[[names[i]]] <- default[[i]]
      } else {
        temp <- paste("ERROR: the name ", names[i], " was not found", sep="")
        stop(temp)
      }
    } else if (checkFlag) {
      temp <- checkList[[i]]
      if (!all(is.na(temp))) {
        if (!all(inList[[names[i]]] %in% checkList[[i]])) {
          temp <- paste("ERROR: the name '", names[i], 
                      "' has an invalid value", sep="")
          stop(temp)
        }
      }
    }
  }

  inList

} # END: default.list

my_LocalDecode <- function(data, init, tran, pi_0, pi_1, 
                           freq_vec, op) {

  op$ms.pi_0 <- pi_0
  op$ms.pi_1 <- pi_1

  # Use same args as in EM call to reuse C code already written
  tmp       <- get_args(data, freq_vec, op)
  iargs     <- tmp$iargs
  dargs     <- tmp$dargs
  kvec      <- numOfStates(data)
  klen      <- length(kvec)
  nr        <- nrow(data)
  nc        <- ncol(data)
  ret_vec   <- rep(-1, nr*nc)

  MISSING   <- 9
  datavec   <- as.vector(t(data))
  tmp       <- !is.finite(datavec)
  if (any(tmp)) datavec[tmp] <- MISSING

  tmp <- .C("MY_C_LocalDecode", as.integer(iargs), as.numeric(dargs), 
            as.integer(datavec), as.integer(freq_vec), as.integer(kvec),
            as.numeric(init), as.numeric(tran),
            ret_vec=as.numeric(ret_vec))
  ret <- matrix(data=tmp$ret_vec, nrow=nr, ncol=nc, byrow=TRUE)

  ret

}

myPasteCols <- function(x, sep="*") {

  nc  <- ncol(x)
  ret <- x[, 1, drop=TRUE]
  if (nc > 1) {
    for (i in 2:nc) ret <- paste(ret, x[, i, drop=TRUE], sep=sep)
  }
  ret
 
}

myDecode <- function(initial_data, state_pattern, init, tran, pi_0, pi_1, 
                      freq_vec, op){

  #Decodes data using output parameters from EM
  #locally_decoded0  <- LocalDecodeProbability(state_pattern,init,tran,pi_0,pi_1)
  locally_decoded  <- my_LocalDecode(state_pattern,init,tran,pi_0,pi_1, freq_vec, op)

  #Goes back to original data size (no pattern)
  state_pattern[is.nan(state_pattern)] <- NA
  ind <- match(myPasteCols(initial_data), myPasteCols(state_pattern))
  ret <- locally_decoded[ind, , drop=FALSE]

  colnames(ret) <- colnames(initial_data)
  
  ret
}

checkCharVec <- function(vec, req, name) {

  tmp <- !(req %in% vec)
  if (any(tmp)) {
    str <- paste0(req[tmp], collapse=", ")
    msg <- paste0("ERROR: ", name, " does not contain ", str)
    stop(msg)
  }

}

checkRiskObj <- function(obj, data) {

  if (!length(obj)) stop("ERROR: obj has length 0")
  if (!is.list(obj)) stop("ERROR: obj must be a list")
  if (!length(data)) stop("ERROR: data must be a data frame")
  if (!is.data.frame(data)) stop("ERROR: data must be a data frame")
  if (!nrow(data)) stop("ERROR: data contains no rows")
  if (!ncol(data)) stop("ERROR: data contains no columns")

  req <- c("cox.estimates", "cox.cov", "event.var")
  nms <- names(obj)
  tmp <- !(req %in% nms)
  if (any(tmp)) {
    str <- paste0(req[tmp], collapse=", ")
    msg <- paste0("ERROR: obj is missing ", str)
    stop(msg)
  }
  nev <- length(obj$event.var)
  if ((nev < 1) | (nev > 2)) stop("ERROR: obj$event.var must be a character vector of length 1 or 2")
  cov.vars <- obj[["cov.vars", exact=TRUE]]
  ncov <- length(cov.vars)
  if (length(cov.vars)) {
    checkCharVec(colnames(data), cov.vars, "data")
  }  
  nparms <- nev*(2 + ncov)
  if (nparms != length(obj$cox.estimates)) stop("ERROR with obj")
  if (nparms != ncol(obj$cox.cov)) stop("ERROR with obj")


}

check_risk.times <- function(obj, rtimes) {

  if (!length(rtimes)) {
    tmp <- obj[["abs.risk", exact=TRUE]]
    if (length(tmp) && is.list(tmp)) rtimes <- tmp[["times", exact=TRUE]] 
  }
  if (!length(rtimes)) stop("ERROR: risk.times must be specified")
  if (!is.vector(rtimes)) stop("ERROR: risk.times must be a numeric vector")
  if (!is.numeric(rtimes)) stop("ERROR: risk.times must be a numeric vector")
  tmp <- !is.finite(rtimes)
  if (any(tmp)) stop("ERROR: risk.times must contain finite values")
  tmp <- rtimes < 0
  tmp[is.na(tmp)] <- FALSE
  if (any(tmp)) stop("ERROR: risk.times must contain non-negative values")
  rtimes

}


getAbsRisk <- function(obj, newdata, risk.times=NULL) {

  # Check input
  checkRiskObj(obj, newdata)  
  risk.times <- check_risk.times(obj, risk.times)

  nev        <- length(obj$event.var)
  cov.vars   <- obj[["cov.vars", exact=TRUE]]
  ncovar     <- length(cov.vars)
  nr         <- nrow(newdata)
  if (ncovar) {
    xids  <- myPasteCols(newdata[, cov.vars, drop=FALSE], sep=":")
    uids  <- unique(xids)
    rows  <- match(xids, uids)
    tmp   <- !duplicated(xids)
    data2 <- newdata[tmp, cov.vars, drop=FALSE]   
  } else {
    data2 <- NULL
  }
  if (nev == 1) {
    ret <- gcuminc1(obj$cox.estimates, obj$cox.cov, data2, risk.times)
  } else {
    ret <- gcuminc2(obj$cox.estimates, obj$cox.cov, data2, risk.times)
  }
  if (ncovar) {
    ret$absRisk    <- ret$absRisk[rows, , drop=FALSE] 
    ret$absRisk.se <- ret$absRisk.se[rows, , drop=FALSE]
  } else {
    ret$absRisk    <- matrix(rep(ret$absRisk, times=nr),    nrow=nr, ncol=length(risk.times), byrow=TRUE)
    ret$absRisk.se <- matrix(rep(ret$absRisk.se, times=nr), nrow=nr, ncol=length(risk.times), byrow=TRUE)
  }
  
  ret
}

